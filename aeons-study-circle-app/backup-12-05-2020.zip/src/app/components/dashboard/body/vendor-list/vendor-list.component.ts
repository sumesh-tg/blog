import { Component, OnInit } from '@angular/core';
import { VendorService } from 'src/app/services/vendor.service';
import { AppConstants } from 'src/app/shared/AppConstants';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-vendor-list',
  templateUrl: './vendor-list.component.html',
  styleUrls: ['./vendor-list.component.scss']
})
export class VendorListComponent implements OnInit {
  public vendorsList = [];
  baseUrl = AppConstants.SERVER_BASE_URL;
  constructor(private vendorService: VendorService,private toastr: ToastrService) { }

  ngOnInit(): void {
    this.vendorService.getVendorsList().subscribe(data => {
      this.vendorsList = data;
      console.log("", data);
    });
    console.log("test data fetched ::", this.vendorsList);
  }
  findPlan(planId: number) {
    var planName;
    AppConstants.PLANS_ARRAY.forEach(plan => {
      if (plan.id === planId) {
        planName = plan.name;
      }
    });
    return planName;
  }
  findStatus(statusId: number) {
    var statusName;
    AppConstants.VENDOR_STATUS_ARRAY.forEach(status => {
      if (status.id === statusId) {
        statusName = status.name
      }
    });
    return statusName;
  }
  deactivateVendor(vendorModel) {
    console.log(vendorModel);
    vendorModel.statusId=(vendorModel.statusId==1)?2:1;
    this.vendorService.updateVendor(vendorModel).subscribe(data => {
      this.toastr.success('Vendor updated successfully!', 'Success');
    });
  }
  deleteVendor(vendorModel) {
    this.vendorService.deleteVendor(vendorModel).subscribe(data => {
      this.vendorsList.splice(this.vendorsList.indexOf(vendorModel),1);
      this.toastr.warning('Vendor deleted successfully!', 'Success');
    });
  }
}
